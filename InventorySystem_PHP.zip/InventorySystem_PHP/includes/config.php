<?php
  define( 'DB_HOST', 'database-1.cza86zaqydzg.us-east-1.rds.amazonaws.com' );          // Set database host
  define( 'DB_USER', 'admin' );             // Set database user
  define( 'DB_PASS', 'lab-password' );             // Set database password
  define( 'DB_NAME', 'sample' );        // Set database name

?>
